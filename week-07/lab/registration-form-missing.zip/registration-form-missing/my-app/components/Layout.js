export default function Layout(props) {
  return (
    <div style={{ padding: "10px", maxWidth: "600px" }}>
      <h2>Week 7 &mdash; Registration</h2>
      <hr />
      {props.children}
    </div>
  );
}
