# Registration Form &mdash; Starter

This is the **starter** for the Week 7 forms lab. Follow the walkthrough in
**`week-07-lab.md`** to complete it.

## What works

- The app runs and the registration form **renders** with every control
  (text, email, password, number, select, radio, textarea, checkboxes).

## What is missing

- The form is **not** wired up to React Hook Form yet &mdash; the submit button only
  logs a `TODO` to the console and nothing is validated.
- Look for `TODO (Part 1)` and `TODO (Part 2)` comments in **`pages/index.js`** to see
  exactly where you need to add code.

## Run it

```
npm install
npm run dev
```

Then browse <http://localhost:3000>.

> In **Part 1** you will install React Hook Form with `npm i react-hook-form`.

A finished reference is available in the **`registration-form-complete`** folder.
