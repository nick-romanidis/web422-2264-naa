import { useState } from "react";

// TODO (Part 1): import the "useForm" hook from "react-hook-form" (after you run
//   "npm i react-hook-form"). You will also need "useEffect" from "react".
//
//   import { useForm } from "react-hook-form";
//   import { useEffect, useState } from "react";

export default function RegisterPage() {
  // TODO (Part 1): replace this with the React Hook Form "useForm" hook, e.g.
  //   const {
  //     register,
  //     handleSubmit,
  //     setValue,
  //     watch,
  //     formState: { errors },
  //   } = useForm({ defaultValues: { username: "", email: "", /* ...etc */ } });
  const [submitted] = useState(null);

  // TODO (Part 1): pre-fill the form from "saved" data using setValue inside a useEffect:
  //   useEffect(() => {
  //     const data = { username: "homer", email: "homer@example.com", age: 39, country: "ca" };
  //     for (const prop in data) setValue(prop, data[prop]);
  //   }, []);

  // TODO (Part 1): once React Hook Form is wired up this becomes:
  //   function submitForm(data) { console.log(data); setSubmitted(data); }
  //   and the <form> should use onSubmit={handleSubmit(submitForm)}.
  function submitForm(e) {
    e.preventDefault();
    console.log("TODO: wire up React Hook Form");
  }

  return (
    <div>
      <h2>Create your account</h2>
      <form onSubmit={submitForm}>
        {/* TODO (Part 1): register each control -> {...register("fieldName")} */}
        {/* TODO (Part 2): add validation rules + error <span>s + the "inputError" class */}
        Username:
        <br />
        <input name="username" />
        <br />
        <br />
        Email:
        <br />
        <input type="email" name="email" />
        <br />
        <br />
        Password:
        <br />
        <input type="password" name="password" />
        <br />
        <br />
        Confirm Password:
        <br />
        {/* TODO (Part 2): custom "validate" rule that matches the watched "password" value */}
        <input type="password" name="confirmPassword" />
        <br />
        <br />
        Age:
        <br />
        <input type="number" name="age" />
        <br />
        <br />
        Country:
        <br />
        <select name="country">
          <option value="">-- choose --</option>
          <option value="ca">Canada</option>
          <option value="us">United States</option>
          <option value="other">Other</option>
        </select>
        <br />
        <br />
        Plan:
        <br />
        <input type="radio" name="plan" value="free" /> Free
        <br />
        <input type="radio" name="plan" value="pro" /> Pro
        <br />
        <br />
        <br />
        Bio:
        <br />
        <textarea name="bio" />
        <br />
        <br />
        <input type="checkbox" name="newsletter" /> Subscribe to newsletter
        <br />
        <input type="checkbox" name="terms" /> I accept the terms
        <br />
        <br />
        {/* TODO (Part 2): disable when in error -> disabled={Object.keys(errors).length > 0} */}
        <button type="submit">Create Account</button>
      </form>

      {/* Once Part 1 is wired up, the submitted data will appear here. */}
      {submitted && (
        <>
          <hr />
          <h3>Submitted data</h3>
          <pre>{JSON.stringify(submitted, null, 2)}</pre>
        </>
      )}
    </div>
  );
}
